clear
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #purple
ku='\033[33;1m' #kuning
echo
echo
python2 meizu.py
echo
clear
echo
echo $red"          Tool akan di install otomatis"
echo $red"            harap sabar menunggu yaa Beb:* :v("   
sleep 1
echo '''\a
\033[34;1m                              _
\033[34;1m                             / |
\033[34;1m                             | |
\033[34;1m                             | |
\033[34;1m                            _|_|_ '''
sleep 1
apt update && apt upgrade
apt install nano
apt install git
pkg install python python2 vim figlet curl
clear
echo
echo
echo
echo
echo $red"         Tool akan di install otomatis"
echo $red"            harap sabar menunggu yaa Beb:* :v"
sleep 1
echo '''\a
\033[32;1m                             ____
\033[32;1m                            |___ \
\033[32;1m                             __) |
\033[32;1m                            / __/
\033[32;1m                           |_____| '''
sleep 1
apt install php
pip2 install mechanize
pip2 install lolcat
pip2 install requests
clear
echo
echo
echo
echo
echo $red"         Tool akan di install otomatis"
echo $red"            harap sabar menunggu yaa Beb:* :v"
sleep 1
echo '''\a
\033[35;1m                            _____
\033[35;1m                           |___ /
\033[35;1m                             |_ \
\033[35;1m                            ___) |
\033[35;1m                           |____/ '''
sleep 1
clear
echo
echo
echo
echo
echo $red"         Tool akan di install otomatis"
echo $red"            harap sabar menunggu yaa Beb:* :v"
sleep 1
echo '''\a
\033[33;1m                            _  _
\033[33;1m                           | || |
\033[33;1m                           | || |_
\033[33;1m                           |__   _|
\033[33;1m                              |_| '''
sleep 1
clear
echo
echo
echo
echo
echo $red"         Tool akan di install Otomatis"
echo $red"            harap sabar menunggu yaa Beb:* :v"
sleep 1
echo '''\a
\033[36;1m                             ____
\033[36;1m                            | ___|
\033[36;1m                            |___ \
\033[36;1m                             ___) |
\033[36;1m                            |____/ '''
sleep 1
clear
echo
echo $pur"==================="$cy" ==================="
echo $i"CBS"$pu"  AUTHOR  :  Mr.V4N  "$i"                   CBS"
echo $i"CBS"$pu"  WhatsApp:  08233020xxxx"$i"                CBS"
echo $i"CBS"$pu"  GMAIL   :  cbthackerteam@gmail.com"$i"    CBS"
echo $i"CBS"$pu"  YOUTUBE :  OfficeGamer4"$i"                CBS"
echo $pur"==================="$cy" ==================="
echo
echo $cy"MeNu BRUTEPORCE NeWS:"
echo $b "1.   REPORT FB";
echo $b "=========================" | lolcat
echo $b "2.   BRUTE PORCE";
echo $b "=========================" | lolcat
echo $b "3.   BRUTE FORCE FB CRACKER";
echo $b "=========================" | lolcat
echo $b "4.   MBF";
echo $b "=========================" | lolcat
echo $b "5.   CLONING YAHOO";
echo $b "=========================" | lolcat
echo $b "6.   OSIF";
echo $b "=========================" | lolcat
echo $b "7.   PROFILEGUARD FB";
echo $b "=========================" | lolcat
echo $b "8.   BOT REACTION FACEBOOK";
echo $b "=========================" | lolcat
echo $b "9.   SPAM CALL";
echo $b "=========================" | lolcat
echo $b "10.  SPAM WHATSHAPP";
echo $b "=========================" | lolcat
echo $b "11.   YOUTUBE-DL";
echo $b "=========================" | lolcat
echo $b "12.   LACAK LOKASI";
echo $b "=========================" | lolcat
echo $i"["$me"13"$i"]"$ku" EXIT";
echo $b "=========================" | lolcat
echo
echo $pur"~root#["$pur"Masukkan pilihan anda"$pur"]"
read -p"Ngahhh>> " pil

if [ $pil = 1 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/VanGanteng/Report
cd Report
unzip Report.zip
python2 Report.py
fi

if [ $pil = 2 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/Senitopeng/fbbrute.git
cd fbbrute
python2 jomblo.py
fi

if [ $pil = 3 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/FR13ND8/Fb-Cracker-v.3.git
cd Fb-Cracker-v.3
python2 crack.py
fi

if [ $pil = 4 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/tikuskecil/multi-bruteforce-facebook.git
cd multi-bruteforce-facebook
python2 MBF.py
fi

if [ $pil = 5 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/wahyuandhika/YahooCloning.git
cd YahooCloning
pip2 install requests mechanize
pip2 install requirements
python2 cloning.py
fi

if [ $pil = 6 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/CiKu370/OSIF.git
cd OSIF
pip2 install -r requirements.txt
python2 osif.py
fi

if [ $pil = 7 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/jaxBCD/FBshield.git
cd FBshield
python2 guard.py
fi

if [ $pil = 8 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/edi-nasa12/ROBOT.git
cd ROBOT
python2 blackbot.py
fi

if [ $pil = 9 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/Aditya021/SpamCall
cd SpamCall
php SpamCall.php
fi

if [ $pil = 10 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/4L13199/LITESPAM.git
cd LITESPAM
sh LITESPAM.sh
fi

if [ $pil = 11 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/rahmadxyz/sub-bot.git
cd sub-bot
php sub-bot.php
fi

if [ $pil = 12 ]
then
clear
figlet -f slant "W A I T C O E G"|lolcat
sleep 1
git clone https://github.com/thelinuxchoice/locator.git
cd locator
bash locator.sh
fi

if [ $pil = 13 ]
then
clear
figlet -f slant "W A I T C O E G"|Ulolcat
sleep 2
echo $cy"Terima Kasih sudah mengunakan Tools ini"
sleep 2
echo $i"Silahkan di pakai semoga bermanfaat Buat anda"
sleep 2
echo $pur"Bila Ada Kesalahan Anda Bisa Nanya Melalui Via"
sleep 2
echo $ku"Facebook :"$i" TanpaNama"
echo $ku"YouTube  :"$i" OfficeGamer4"
echo $ku"WhatsApp :"$i" 08233020xxxx"
sleep 2
echo $pur"Terima kasih Yang Sudah Support dengan Tools ini"
sleep 2
echo $pur"SUBSCRIBE MY CHANNEL { OFFICEGAMER4 }"
exit
fi
